using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using TechTalk.SpecFlow;

namespace TestProject1_MsTest
{
    [Binding]
    public class CaseManagementStep
    {
        private readonly CaseManagementFeatureHelper _caseMgmtFeatureHelper;
        public CaseManagementStep(CaseManagementFeatureHelper caseMgmtFeatureHelper)
        {
            _caseMgmtFeatureHelper = caseMgmtFeatureHelper;
        }


        [When(@"user sends the request to CaseManagementAPI (.*) with the following (.*)")]
        public void WhenUserSendsTheRequestToCaseManagementAPIOrganizationTreeApiGetForManageSecurityWithTheFollowingAdminPermissions(string method, string permissions)
        {
            dynamic api = _caseMgmtFeatureHelper.GetAPIClient(method);
            if (method == null)
                throw new ArgumentNullException(nameof(method));
           
           
        }

        [Then(@"user sees the case management status (.*)")]
        public void ThenUserSeesTheCaseManagementStatus(string statusCodeExpected)
        {
            Assert.AreEqual(statusCodeExpected,200/500);
        }
    }

    
}
