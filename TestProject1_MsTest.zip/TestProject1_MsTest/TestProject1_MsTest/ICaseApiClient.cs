﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject1_MsTest
{
    internal interface ICaseApiClient
    {
        IHttpResponse<int> Create();
    }
}
