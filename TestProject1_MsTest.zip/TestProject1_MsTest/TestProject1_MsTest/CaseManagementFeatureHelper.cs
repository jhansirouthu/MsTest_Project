﻿

using System;
using System.Collections.Generic;

namespace TestProject1_MsTest
{
    
    public class CaseManagementFeatureHelper
    {
        private Dictionary<dynamic, dynamic> _apiClients;
        private dynamic _organizationTreeApiClient;
        private dynamic _managingClientApiClient;
        private dynamic _enterpriseClientPropertyApiClient;
        
        private dynamic _clientApiClient;
        private readonly ICaseApiClient _caseApiClient;

        public CaseManagementFeatureHelper()
        {
            _apiClients = new Dictionary<dynamic, dynamic>();
            _apiClients.Add("OrganizationTreeApi", _organizationTreeApiClient);
            _apiClients.Add("ManagingClientApi", _managingClientApiClient);
            _apiClients.Add("EnterpriseClientPropertyApi", _enterpriseClientPropertyApiClient);
            _apiClients.Add("CaseApi", _caseApiClient);
            _apiClients.Add("ClientApi", _clientApiClient);
        }

        public void GetCaseObj()
        {
           /*var id = _caseApiClient.Create();
            var response= _caseApiClient.GetCaseById(id.Body);
            return response.Body;*/
           
        }

        public dynamic GetAPIClient(string method)
        {
            return this._apiClients[method.Split('/')[0]];
        }
    }
}
