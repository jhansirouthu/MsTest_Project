﻿namespace TestProject1_MsTest
{
    public interface IHttpResponse<T>
    {
    }
}