using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using TechTalk.SpecFlow;

namespace TestProject1_MsTest
{
    
    [Binding]
    public class DataSetupHook
    {
         public static int Vnum1,Vnum2;
        
        public DataSetupHook()
        {
            //this.num1 = num1;
        }


        [BeforeTestRun]

        public static void num1()
        {
            Vnum1 = 3;


        }
        [BeforeScenario("Numeber2", Order = 2)]
        public static void num2()
        {
            Vnum2 = 3;
        }

        [AfterScenario]
        public static void cleanUp()
        {
            Vnum2 = Vnum1 = 0;
        }
       
    }
}