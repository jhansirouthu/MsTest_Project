﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject1_MsTest
{
    [TestClass]
    public class sample
    {
        [TestMethod]
        public void jhansi()
        {
            
        }
    }
}
