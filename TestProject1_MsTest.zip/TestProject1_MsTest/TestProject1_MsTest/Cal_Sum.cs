using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject1_MsTest
{
 
    [TestClass]
    public class Cal_Sum
    {
        [TestMethod]
        public void Sum()
        {
           int num1=3,num2=3;

            int sum = num1 + num2;
            
        }
    }
}